use(function () {

var text = properties.get("desc");

var img = properties.get("img");

    return{
    xyz : text,
    img : img
    };

});