
alert("this is virus");